# jquery-gallery
Jquery gallery with thumbnails
