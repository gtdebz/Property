$('#zoom_10').ezPlus({
    easing: true
});
