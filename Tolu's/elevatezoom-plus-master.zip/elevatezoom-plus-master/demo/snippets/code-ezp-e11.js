$("#zoom_11").ezPlus({
    zoomLevel: 0.5
});
