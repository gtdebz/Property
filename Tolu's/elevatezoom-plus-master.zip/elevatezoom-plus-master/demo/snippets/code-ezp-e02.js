$("#zoom_02").ezPlus({
    tint: true,
    tintColour: '#F90', tintOpacity: 0.5
});
