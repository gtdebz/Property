$('#zoom_07').ezPlus({
    zoomType: 'lens',
    lensShape: 'round',
    lensSize: 200
});
