$('#zoom_05').ezPlus({
    zoomType: 'inner',
    cursor: 'crosshair'
});
