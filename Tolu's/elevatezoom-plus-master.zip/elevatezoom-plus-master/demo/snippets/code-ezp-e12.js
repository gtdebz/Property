$('#zoom_13').ezPlus({
    zoomWindowWidth: 300,
    zoomWindowHeight: 100
});

$('#zoom_14').ezPlus({
    zoomWindowWidth: 100,
    zoomWindowHeight: 300
});
