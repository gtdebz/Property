$('#zoom_mw').ezPlus({
    scrollZoom: true
});
