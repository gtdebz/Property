$('#zoom_04a').ezPlus({
    zoomWindowPosition: 1
});
$('#zoom_04b').ezPlus({
    zoomWindowPosition: 12
});
$('#zoom_04c').ezPlus({
    zoomWindowPosition: 'demo-container',
    zoomWindowHeight: 200,
    zoomWindowWidth: 200,
    borderSize: 0,
    easing: true
});
$('#zoom_04d').ezPlus({
    zoomWindowPosition: 1,
    zoomWindowOffsetX: 10
});
