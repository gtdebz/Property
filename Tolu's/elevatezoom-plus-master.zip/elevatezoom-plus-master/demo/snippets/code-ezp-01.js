$("#zoom_04").ezPlus();
